package com.wod.wodDBProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WodDbProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
